"use client";
import { useEffect, useState } from "react";
import { getDocs, query, Timestamp, where } from "firebase/firestore";
import { QRCodeSVG } from "qrcode.react";
import { Check, CheckCheck, CircleCheck, Copy, Gift, IdCard, Loader2, Palette, QrCode, Shapes, Target, Users } from "lucide-react";
import { WalletCard } from "@/components/card/wallet-card";
import { OwnerGate } from "@/components/shared/owner-gate";
import { Panel, inputCls } from "@/components/shared/panel";
import { updateBusiness } from "@/lib/firebase/businesses";
import { cardsCol, historyCol } from "@/lib/firebase/collections";
import { STAMP_TYPES } from "@/lib/stamp-types";
import type { Business } from "@/lib/firebase/types";

const EDITIONS = [
  { name: "Obsidian Black Edition", color: "#131515" },
  { name: "Warm Taupe Edition", color: "#6f6866" },
];
const SIZES = [6, 8, 10, 12];
const chip = "inline-flex items-center gap-1.5 rounded-full border border-borde bg-white px-3 py-1.5 text-xs font-bold text-texto";

export function BusinessEditor() {
  return <OwnerGate>{(b) => <Editor key={b.slug} initial={b} />}</OwnerGate>;
}

function useStats(slug: string) {
  const [stats, setStats] = useState<{ clients: number; today: number; redeemed: number } | null>(null);
  useEffect(() => {
    let cancelled = false;
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    Promise.all([
      getDocs(cardsCol(slug)),
      getDocs(query(historyCol(slug), where("createdAt", ">=", Timestamp.fromDate(start)))),
    ])
      .then(([cards, today]) => {
        if (cancelled) return;
        setStats({
          clients: cards.size,
          redeemed: cards.docs.reduce((n, d) => n + d.data().redeemedCount, 0),
          today: today.docs.reduce((n, d) => (d.data().type === "stamp" ? n + d.data().amount : n), 0),
        });
      })
      .catch(() => { if (!cancelled) setStats({ clients: 0, today: 0, redeemed: 0 }); });
    return () => { cancelled = true; };
  }, [slug]);
  return stats;
}

function Editor({ initial }: { initial: Business }) {
  const [name, setName] = useState(initial.name);
  const [color, setColor] = useState(initial.primaryColor);
  const [stampIcon, setStampIcon] = useState(initial.stampIcon ?? "general");
  const [required, setRequired] = useState(initial.stampsRequired);
  const [reward, setReward] = useState(initial.reward);
  const [description, setDescription] = useState(initial.description ?? "");
  const [address, setAddress] = useState(initial.address ?? "");
  const [hours, setHours] = useState(initial.hours ?? "");
  const [phone, setPhone] = useState(initial.phone ?? "");
  const [status, setStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [copied, setCopied] = useState(false);
  const stats = useStats(initial.slug);
  const link = typeof window === "undefined" ? "" : `${window.location.origin}/c/${initial.slug}`;
  const custom = !EDITIONS.some((e) => e.color === color.toLowerCase());

  async function save() {
    setStatus("saving");
    try {
      await updateBusiness(initial.slug, {
        name: name.trim() || initial.name, primaryColor: color, stampsRequired: required, reward: reward.trim() || initial.reward,
        stampIcon, description: description.trim() || null, address: address.trim() || null, hours: hours.trim() || null, phone: phone.trim() || null,
      });
      setStatus("saved");
      setTimeout(() => setStatus("idle"), 2000);
    } catch {
      setStatus("error");
    }
  }

  const radio = (active: boolean) => `flex min-h-14 w-full items-center gap-3 rounded-xl border bg-white px-3.5 text-left transition-colors ${active ? "border-2 border-boton" : "border-borde"}`;

  return (
    <div className="space-y-4">
      <header>
        <h1 className="text-3xl font-extrabold text-texto">Mi negocio</h1>
        <div className="mt-3 flex flex-wrap gap-2">
          <span className={chip}><Users className="size-3.5" /> {stats?.clients ?? "–"} clientes</span>
          <span className={chip}><CheckCheck className="size-3.5" /> {stats?.today ?? "–"} sellos hoy</span>
          <span className={chip}><Gift className="size-3.5" /> {stats?.redeemed ?? "–"} canjeados</span>
        </div>
      </header>

      <section>
        <div className="mb-2 flex items-center justify-between text-[11px] font-bold">
          <span className="flex items-center gap-1.5 text-texto"><span className="size-2 rounded-full bg-emerald-500" /> VISTA PREVIA EN VIVO</span>
          <span className="font-medium text-texto-sec">Actualización instantánea</span>
        </div>
        <WalletCard name={name || "Tu negocio"} color={color} reward={reward || "Tu premio"} required={required} filled={Math.ceil(required * 0.4)} typeKey={stampIcon} />
      </section>

      <Panel icon={Shapes} title="Tipo de negocio y sello" subtitle="Elegí el ícono que se graba en cada visita">
        <div className="grid grid-cols-4 gap-2">
          {STAMP_TYPES.map((t) => (
            <button key={t.key} type="button" onClick={() => setStampIcon(t.key)} aria-pressed={stampIcon === t.key}
              className={`flex aspect-square flex-col items-center justify-center gap-1.5 rounded-xl text-[11px] font-bold transition-all active:scale-95 ${stampIcon === t.key ? "bg-boton text-white" : "border border-borde bg-white text-texto"}`}>
              <t.icon className="size-5" />{t.label}
            </button>
          ))}
        </div>
      </Panel>

      <Panel icon={Palette} title="Color y estilo de la tarjeta" subtitle="La estética característica de tu comercio">
        <div className="space-y-2" role="radiogroup">
          {EDITIONS.map((e) => (
            <button key={e.color} type="button" role="radio" aria-checked={color.toLowerCase() === e.color} onClick={() => setColor(e.color)} className={radio(color.toLowerCase() === e.color)}>
              <span className="size-5 shrink-0 rounded-full ring-1 ring-black/10" style={{ background: e.color }} />
              <span className="flex-1 text-sm font-bold text-texto">{e.name} <span className="font-medium text-texto-sec">({e.color.toUpperCase()})</span></span>
              {color.toLowerCase() === e.color && <Check className="size-4 text-texto" strokeWidth={3} />}
            </button>
          ))}
          <label className={`${radio(custom)} cursor-pointer`}>
            <span className="size-5 shrink-0 rounded-full ring-1 ring-black/10" style={{ background: custom ? color : "conic-gradient(red, yellow, lime, aqua, blue, magenta, red)" }} />
            <span className="flex-1 text-sm font-bold text-texto">Color propio</span>
            <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="size-7 cursor-pointer rounded-full border-0 bg-transparent p-0" aria-label="Elegir color propio" />
          </label>
        </div>
      </Panel>

      <Panel icon={IdCard} title="Identidad y marca" subtitle="Nombre y datos que ven tus clientes">
        <div className="space-y-3">
          <label className="block text-xs font-bold text-texto">Nombre comercial en la tarjeta<input value={name} onChange={(e) => setName(e.target.value)} maxLength={40} className={`${inputCls} mt-1.5 font-normal`} /></label>
          <label className="block text-xs font-bold text-texto">Descripción<textarea value={description} onChange={(e) => setDescription(e.target.value)} maxLength={160} rows={2} className={`${inputCls} mt-1.5 py-3 font-normal`} /></label>
          <label className="block text-xs font-bold text-texto">Dirección<input value={address} onChange={(e) => setAddress(e.target.value)} maxLength={100} className={`${inputCls} mt-1.5 font-normal`} /></label>
          <label className="block text-xs font-bold text-texto">Horarios<input value={hours} onChange={(e) => setHours(e.target.value)} maxLength={80} placeholder="Lun a Sáb 8:00 – 20:00" className={`${inputCls} mt-1.5 font-normal`} /></label>
          <label className="block text-xs font-bold text-texto">Teléfono<input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={24} className={`${inputCls} mt-1.5 font-normal`} /></label>
        </div>
      </Panel>

      <Panel icon={Target} title="Reglas de sellos y recompensas" subtitle="Establecé la meta de visitas y el premio final">
        <p className="text-xs font-bold text-texto">Sellos necesarios para completar</p>
        <div className="mt-2 grid grid-cols-4 gap-2" role="radiogroup">
          {SIZES.map((n) => (
            <button key={n} type="button" role="radio" aria-checked={required === n} onClick={() => setRequired(n)}
              className={`min-h-12 rounded-xl text-sm font-bold transition-all active:scale-95 ${required === n ? "bg-boton text-white" : "border border-borde bg-white text-texto"}`}>{n}</button>
          ))}
        </div>
        <label className="mt-4 block text-xs font-bold text-texto">Recompensa final principal<input value={reward} onChange={(e) => setReward(e.target.value)} maxLength={48} className={`${inputCls} mt-1.5 font-normal`} /></label>
      </Panel>

      <Panel icon={QrCode} title="Compartí tu tarjeta" subtitle="Tus clientes escanean este QR para crear la suya">
        <div className="mx-auto w-fit rounded-2xl border border-borde bg-white p-3">{link && <QRCodeSVG value={link} size={150} marginSize={0} />}</div>
        <button type="button" onClick={() => navigator.clipboard.writeText(link).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1800); })}
          className="mx-auto mt-3 flex min-h-11 items-center gap-2 rounded-full border border-borde bg-white px-4 text-xs font-bold text-texto"><Copy className="size-3.5" /> {copied ? "Link copiado" : "Copiar link"}</button>
      </Panel>

      {status === "error" && <p role="alert" className="rounded-xl border border-error/20 bg-error-suave px-3 py-2.5 text-sm text-error">No se pudieron guardar los cambios. Revisá tu conexión e intentá de nuevo.</p>}
      <div className="sticky bottom-24 z-10">
        <button type="button" onClick={save} disabled={status === "saving"}
          className={`flex min-h-14 w-full items-center justify-center gap-2 rounded-2xl text-base font-bold text-white shadow-lg shadow-black/25 transition-all active:scale-[0.98] disabled:opacity-70 ${status === "saved" ? "bg-exito" : "bg-boton"}`}>
          {status === "saving" ? <Loader2 className="size-5 animate-spin" /> : <CircleCheck className="size-5" />}
          {status === "saved" ? "Cambios publicados" : "Guardar y publicar tarjeta"}
        </button>
      </div>
    </div>
  );
}
